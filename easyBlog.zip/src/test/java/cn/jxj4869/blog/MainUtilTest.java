package cn.jxj4869.blog;

import cn.jxj4869.blog.utils.MainUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class MainUtilTest {



    @Autowired
    MainUtil mainUtil;

//    @Test
//    public void senderTest () {
//            mainUtil.sendCheckCodeEmail("1121429190@qq.com","测试端口");
//    }
}
