package cn.jxj4869.blog.entity;

import java.util.HashMap;

public class Info extends HashMap<String,Object> {
}
