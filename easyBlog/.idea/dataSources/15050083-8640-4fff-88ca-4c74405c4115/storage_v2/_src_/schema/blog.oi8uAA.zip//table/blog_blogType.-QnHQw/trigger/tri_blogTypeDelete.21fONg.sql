create definer = aliyun@`%` trigger tri_blogTypeDelete
    before delete
    on blog_blogType
    for each row
begin
    declare id int;
    select bt.id into id from blog_blogType bt where bt.id = old.id;
    update `blog_blog` set `typeid`=null where `blog_blog`.typeId = id;
end;

